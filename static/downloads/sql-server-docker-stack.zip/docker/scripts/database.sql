USE master
GO

-- Create the cdc DB if not exists
IF NOT EXISTS (
    SELECT
        name
    FROM
        sys.databases
    WHERE
        name = 'cdc'
)
CREATE DATABASE cdc
GO

USE cdc
GO

-- Enable CDC if is disabled
IF NOT EXISTS (
    SELECT
        is_cdc_enabled
    FROM
        sys.databases
    WHERE
        name = 'cdc'
        AND is_cdc_enabled = 1
)
EXEC sys.sp_cdc_enable_db
GO

PRINT 'DB created and configured'
GO
