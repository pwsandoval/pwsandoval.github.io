USE pw0
GO

IF NOT EXISTS (
    SELECT
        name
    FROM
        sysobjects
    WHERE
        name = 'sensor'
        AND xtype = 'U'
)
CREATE TABLE
    sensor (
        -- id INT IDENTITY(1, 1) PRIMARY KEY,
        created_at DATETIME,
        temperature FLOAT,
        humidity FLOAT,
        pressure FLOAT,
        lux FLOAT
)
GO

IF NOT EXISTS (
    SELECT
        TOP 1 *
    FROM
        sensor
    )
BULK INSERT sensor
FROM
    '/usr/config/sample-data/room-climate.csv'
WITH
    (
        FIELDTERMINATOR = ',',
        ROWTERMINATOR = '\n',
        FIRSTROW = 2,
        TABLOCK
    )
GO

PRINT 'TB created and populated with dummy records'
GO
