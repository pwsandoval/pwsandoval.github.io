USE master
GO

-- Create the DB if not exists
IF NOT EXISTS (
    SELECT
        name
    FROM
        sys.databases
    WHERE
        name = 'pw0'
)
CREATE DATABASE pw0
GO

PRINT 'DB pw0 created or already exists'
GO
